/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.undra.app.util;

/**
 *
 * @author alexandre
 */
public class Messages {

    static public String RUNNING_TESTS = "\n\n---------------------------->>>>>>>>>>>> RUNNING TESTS <<<<<<<<<<<<<------------------------------\n\n";
    static public String FINISHED_RUNNING_TESTS = "\n-----------------------------------------------------------------------------------------------";
    static public String APP_STARTING="\n\n......................................APP STARTING...\n";
    static public String APP_STARTED="\n\n......................................APP STARTED...\n";
    static public String APP_RUNNING="\n\n......................................APP RUNNING...\n";
    static public String APP_SHUTINGDOWN="\n\n......................................APP SHUTINGDOWN...\n";

}
