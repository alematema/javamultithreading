package br.edu.undra.model.exceptions;

public class LowerCaseEncoderException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
