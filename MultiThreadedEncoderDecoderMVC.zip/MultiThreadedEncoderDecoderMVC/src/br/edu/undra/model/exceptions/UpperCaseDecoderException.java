package br.edu.undra.model.exceptions;

public class UpperCaseDecoderException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
