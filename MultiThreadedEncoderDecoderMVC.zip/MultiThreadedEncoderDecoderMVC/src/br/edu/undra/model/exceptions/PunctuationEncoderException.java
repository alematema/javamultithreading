package br.edu.undra.model.exceptions;

public class PunctuationEncoderException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}
